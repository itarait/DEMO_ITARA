[![Build Status](https://travis-ci.org/OCA/account-consolidation.svg?branch=master)](https://travis-ci.org/OCA/account-consolidation)
[![Coverage Status](https://img.shields.io/coveralls/OCA/account-consolidation.svg)](https://coveralls.io/r/OCA/account-consolidation?branch=master)

Account Consolidation
=====================

Consolidate chart of accounts on subsidiaries in a virtual chart of accounts of the holding.

[//]: # (addons)

Unported addons
---------------
addon | version | summary
--- | --- | ---
[account_consolidation](account_consolidation/) | 1.0 (unported) | Account Consolidation
[account_parallel_currency](account_parallel_currency/) | 0.2 (unported) | Account Parallel Currency

[//]: # (end addons)
