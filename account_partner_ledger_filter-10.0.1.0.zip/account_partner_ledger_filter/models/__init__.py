# -*- coding: utf-8 -*-
import account_partner_ledger
